﻿namespace INICIO
{
    partial class usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnGuardar = new Button();
            txtUsuario = new Label();
            txtFecha = new Label();
            txtRol = new Label();
            txtClave = new Label();
            txtCorreo = new Label();
            txtApellido = new Label();
            txtNombre = new Label();
            dateTimePicker1 = new DateTimePicker();
            textBox1 = new TextBox();
            textBox4 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox5 = new TextBox();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(btnGuardar);
            panel1.Controls.Add(txtUsuario);
            panel1.Controls.Add(txtFecha);
            panel1.Controls.Add(txtRol);
            panel1.Controls.Add(txtClave);
            panel1.Controls.Add(txtCorreo);
            panel1.Controls.Add(txtApellido);
            panel1.Controls.Add(txtNombre);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(textBox4);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(textBox5);
            panel1.Location = new Point(211, 15);
            panel1.Name = "panel1";
            panel1.Size = new Size(383, 448);
            panel1.TabIndex = 7;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(147, 371);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(94, 29);
            btnGuardar.TabIndex = 7;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // txtUsuario
            // 
            txtUsuario.AutoSize = true;
            txtUsuario.Location = new Point(15, 0);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(59, 20);
            txtUsuario.TabIndex = 12;
            txtUsuario.Text = "Usuario";
            // 
            // txtFecha
            // 
            txtFecha.AutoSize = true;
            txtFecha.Location = new Point(47, 295);
            txtFecha.Name = "txtFecha";
            txtFecha.Size = new Size(47, 20);
            txtFecha.TabIndex = 11;
            txtFecha.Text = "Fecha";
            // 
            // txtRol
            // 
            txtRol.AutoSize = true;
            txtRol.Location = new Point(47, 237);
            txtRol.Name = "txtRol";
            txtRol.Size = new Size(31, 20);
            txtRol.TabIndex = 10;
            txtRol.Text = "Rol";
            // 
            // txtClave
            // 
            txtClave.AutoSize = true;
            txtClave.Location = new Point(47, 188);
            txtClave.Name = "txtClave";
            txtClave.Size = new Size(45, 20);
            txtClave.TabIndex = 9;
            txtClave.Text = "Clave";
            // 
            // txtCorreo
            // 
            txtCorreo.AutoSize = true;
            txtCorreo.Location = new Point(47, 137);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(54, 20);
            txtCorreo.TabIndex = 8;
            txtCorreo.Text = "Correo";
            // 
            // txtApellido
            // 
            txtApellido.AutoSize = true;
            txtApellido.Location = new Point(47, 89);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(66, 20);
            txtApellido.TabIndex = 7;
            txtApellido.Text = "Apellido";
            // 
            // txtNombre
            // 
            txtNombre.AutoSize = true;
            txtNombre.Location = new Point(47, 44);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(64, 20);
            txtNombre.TabIndex = 6;
            txtNombre.Text = "Nombre";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(101, 295);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(266, 27);
            dateTimePicker1.TabIndex = 5;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(184, 44);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(142, 27);
            textBox1.TabIndex = 0;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(184, 89);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(142, 27);
            textBox4.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(184, 237);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(142, 27);
            textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(184, 188);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(142, 27);
            textBox3.TabIndex = 2;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(184, 137);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(142, 27);
            textBox5.TabIndex = 4;
            // 
            // usuarios
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(panel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "usuarios";
            Text = "usuarios";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button btnGuardar;
        private Label txtUsuario;
        private Label txtFecha;
        private Label txtRol;
        private Label txtClave;
        private Label txtCorreo;
        private Label txtApellido;
        private Label txtNombre;
        private DateTimePicker dateTimePicker1;
        private TextBox textBox1;
        private TextBox textBox4;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox5;
    }
}