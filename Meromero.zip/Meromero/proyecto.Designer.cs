﻿namespace INICIO
{
    partial class proyecto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(proyecto));
            groupBox1 = new GroupBox();
            Txtdescripcion = new TextBox();
            Txtusuario = new TextBox();
            Txtestado = new TextBox();
            Txtnombrepro = new TextBox();
            Txtidproyecto = new TextBox();
            Btnguardar = new Button();
            Label7 = new Label();
            Label6 = new Label();
            Label5 = new Label();
            Label4 = new Label();
            Label3 = new Label();
            Label2 = new Label();
            Label1 = new Label();
            dgvproyectos = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            dtpinnicio = new DateTimePicker();
            dtpfin = new DateTimePicker();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvproyectos).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.SteelBlue;
            groupBox1.Controls.Add(dtpfin);
            groupBox1.Controls.Add(dtpinnicio);
            groupBox1.Controls.Add(Txtdescripcion);
            groupBox1.Controls.Add(Txtusuario);
            groupBox1.Controls.Add(Txtestado);
            groupBox1.Controls.Add(Txtnombrepro);
            groupBox1.Controls.Add(Txtidproyecto);
            groupBox1.Controls.Add(Btnguardar);
            groupBox1.Controls.Add(Label7);
            groupBox1.Controls.Add(Label6);
            groupBox1.Controls.Add(Label5);
            groupBox1.Controls.Add(Label4);
            groupBox1.Controls.Add(Label3);
            groupBox1.Controls.Add(Label2);
            groupBox1.Controls.Add(Label1);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(195, 47);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(511, 309);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Proyecto";
            // 
            // Txtdescripcion
            // 
            Txtdescripcion.BackColor = SystemColors.ActiveBorder;
            Txtdescripcion.Location = new Point(267, 140);
            Txtdescripcion.Name = "Txtdescripcion";
            Txtdescripcion.Size = new Size(100, 23);
            Txtdescripcion.TabIndex = 27;
            // 
            // Txtusuario
            // 
            Txtusuario.BackColor = SystemColors.ActiveBorder;
            Txtusuario.Location = new Point(267, 103);
            Txtusuario.Name = "Txtusuario";
            Txtusuario.Size = new Size(100, 23);
            Txtusuario.TabIndex = 26;
            // 
            // Txtestado
            // 
            Txtestado.BackColor = SystemColors.ActiveBorder;
            Txtestado.Location = new Point(267, 74);
            Txtestado.Name = "Txtestado";
            Txtestado.Size = new Size(100, 23);
            Txtestado.TabIndex = 25;
            // 
            // Txtnombrepro
            // 
            Txtnombrepro.BackColor = SystemColors.ActiveBorder;
            Txtnombrepro.Location = new Point(267, 39);
            Txtnombrepro.Name = "Txtnombrepro";
            Txtnombrepro.Size = new Size(100, 23);
            Txtnombrepro.TabIndex = 24;
            // 
            // Txtidproyecto
            // 
            Txtidproyecto.BackColor = SystemColors.ActiveBorder;
            Txtidproyecto.Location = new Point(267, 7);
            Txtidproyecto.Name = "Txtidproyecto";
            Txtidproyecto.Size = new Size(100, 23);
            Txtidproyecto.TabIndex = 23;
            // 
            // Btnguardar
            // 
            Btnguardar.BackColor = Color.SteelBlue;
            Btnguardar.FlatAppearance.BorderSize = 0;
            Btnguardar.FlatAppearance.MouseOverBackColor = SystemColors.ActiveBorder;
            Btnguardar.FlatStyle = FlatStyle.Flat;
            Btnguardar.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btnguardar.ForeColor = Color.White;
            Btnguardar.Location = new Point(231, 279);
            Btnguardar.Name = "Btnguardar";
            Btnguardar.Size = new Size(168, 23);
            Btnguardar.TabIndex = 22;
            Btnguardar.Text = "GUARDAR PROYECTO";
            Btnguardar.UseVisualStyleBackColor = false;
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic);
            Label7.ForeColor = Color.White;
            Label7.Location = new Point(119, 224);
            Label7.Name = "Label7";
            Label7.Size = new Size(68, 17);
            Label7.TabIndex = 21;
            Label7.Text = "FECHA FIN";
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic);
            Label6.ForeColor = Color.White;
            Label6.Location = new Point(114, 184);
            Label6.Name = "Label6";
            Label6.Size = new Size(90, 17);
            Label6.TabIndex = 20;
            Label6.Text = "FECHA INICIO ";
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic);
            Label5.ForeColor = Color.White;
            Label5.Location = new Point(115, 148);
            Label5.Name = "Label5";
            Label5.Size = new Size(86, 17);
            Label5.TabIndex = 19;
            Label5.Text = "DESCRIPCION";
            // 
            // Label4
            // 
            Label4.AutoSize = true;
            Label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic);
            Label4.ForeColor = Color.White;
            Label4.Location = new Point(114, 115);
            Label4.Name = "Label4";
            Label4.Size = new Size(61, 17);
            Label4.TabIndex = 18;
            Label4.Text = "USUARIO";
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic);
            Label3.ForeColor = Color.White;
            Label3.Location = new Point(112, 82);
            Label3.Name = "Label3";
            Label3.Size = new Size(54, 17);
            Label3.TabIndex = 17;
            Label3.Text = "ESTADO";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic);
            Label2.ForeColor = Color.White;
            Label2.Location = new Point(112, 47);
            Label2.Name = "Label2";
            Label2.Size = new Size(127, 17);
            Label2.TabIndex = 16;
            Label2.Text = "NOMBRE PROYECTO";
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Italic);
            Label1.ForeColor = Color.White;
            Label1.Location = new Point(111, 15);
            Label1.Name = "Label1";
            Label1.Size = new Size(87, 17);
            Label1.TabIndex = 15;
            Label1.Text = "ID PROYECTO";
            // 
            // dgvproyectos
            // 
            dgvproyectos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvproyectos.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6 });
            dgvproyectos.Location = new Point(144, 373);
            dgvproyectos.Name = "dgvproyectos";
            dgvproyectos.Size = new Size(620, 65);
            dgvproyectos.TabIndex = 2;
            // 
            // Column1
            // 
            Column1.HeaderText = "NOMBRE PROYECTO";
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "ESTADO";
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "DESCRIPCION";
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.HeaderText = "USUARIO";
            Column4.Name = "Column4";
            // 
            // Column5
            // 
            Column5.HeaderText = "FECHA INICIO";
            Column5.Name = "Column5";
            // 
            // Column6
            // 
            Column6.HeaderText = "FECHA FIN";
            Column6.Name = "Column6";
            // 
            // panel1
            // 
            panel1.BackColor = Color.SteelBlue;
            panel1.Controls.Add(pictureBox2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(889, 41);
            panel1.TabIndex = 3;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(65, 46);
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            // 
            // dtpinnicio
            // 
            dtpinnicio.Location = new Point(267, 178);
            dtpinnicio.Name = "dtpinnicio";
            dtpinnicio.Size = new Size(200, 23);
            dtpinnicio.TabIndex = 30;
            // 
            // dtpfin
            // 
            dtpfin.Location = new Point(267, 218);
            dtpfin.Name = "dtpfin";
            dtpfin.Size = new Size(200, 23);
            dtpfin.TabIndex = 31;
            // 
            // proyecto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveBorder;
            ClientSize = new Size(889, 450);
            Controls.Add(panel1);
            Controls.Add(dgvproyectos);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "proyecto";
            Text = "proyecto";
            Load += proyecto_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvproyectos).EndInit();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        internal TextBox txtfechafin;
        internal TextBox Txtfechainicio;
        internal TextBox Txtdescripcion;
        internal TextBox Txtusuario;
        internal TextBox Txtestado;
        internal TextBox Txtnombrepro;
        internal TextBox Txtidproyecto;
        internal Button Btnguardar;
        internal Label Label7;
        internal Label Label6;
        internal Label Label5;
        internal Label Label4;
        internal Label Label3;
        internal Label Label2;
        internal Label Label1;
        internal DataGridView dgvproyectos;
        internal DataGridViewTextBoxColumn Column1;
        internal DataGridViewTextBoxColumn Column2;
        internal DataGridViewTextBoxColumn Column3;
        internal DataGridViewTextBoxColumn Column4;
        internal DataGridViewTextBoxColumn Column5;
        internal DataGridViewTextBoxColumn Column6;
        private Panel panel1;
        private PictureBox pictureBox2;
        private DateTimePicker dtpfin;
        private DateTimePicker dtpinnicio;
    }
}